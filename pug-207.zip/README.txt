A Pen created at CodePen.io. You can find this one at http://codepen.io/nord-txd/pen/LGqJJY.

 Wanted to illustrate my car to feature on my latest portfolio site, just having fun with animation.